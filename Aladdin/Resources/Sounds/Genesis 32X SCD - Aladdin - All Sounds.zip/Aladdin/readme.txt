Aladdin (MegaDrive) ripped by birdmanager6
Version 1.1

Changelog:
 - Replaced the Menu Select.wav (which was accidently from the DOS version) with the version from the MegaDrive version.
Notes:
 - All sounds are named after the sound test.
 - All samples were ripped from the DOS version, which has identical samples to the MegaDrive version.
 - Some sounds use both the DAC and FM or PSG to make sound effects. For those sound effects, versions with FM or PSG only and together are included.